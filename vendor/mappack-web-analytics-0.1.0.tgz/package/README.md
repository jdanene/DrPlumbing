# MapPack website analytics

This private package loads Google Analytics 4 on explicitly listed production hosts, counts contact-link taps, and lets a site report booking events. It has no runtime dependencies. Nothing has been published to npm or a CDN.

## Install from the file

Build and pack here with `npm ci && npm run check && npm pack`, copy the tarball into the site's `vendor/`, then install in that site:

~~~sh
npm install ./vendor/mappack-web-analytics-0.1.0.tgz
~~~

After the app renders, initialize once with the business owner's public Measurement ID:

~~~ts
import { init, track } from "mappack-web-analytics";
init({ measurementId: "G-XXXXXXXXXX", hosts: ["example.com", "www.example.com"] });
// In the form, at its first input:
track("book_start");
// After the site's server reports success:
track("generate_lead", { service: "Water heaters", city: "Bellevue", urgency: "Today" });
// At the relevant failure:
track("book_failed", { reason: "network" });
~~~

Use the actual categorical field values; pass no other form fields. `stop()` removes the contact listener and disables `track()`. Repeated initialization replaces the listener and does not add another loader.

## Event meanings

| Event | Counts | Does not establish |
|---|---|---|
| GA4 `page_view` | Page loads and history changes when enhanced measurement is enabled | Unique people |
| `call_click` | Phone-link taps | Connected calls |
| `sms_click` | Text-link taps | Sent texts |
| `email_click` | Email-link taps | Sent emails |
| `map_open` | Google Maps link taps | Visits to the business |
| `reviews_click` | Review-link taps, including `data-track="reviews"` | Written reviews |
| `book_start` | First form input, sent by the site | Requests sent |
| `book_failed` | Validation, server or network failure, sent by the site | Spam classification |
| `generate_lead` | Server-success request attempts, sent by the site | Qualified leads or booked jobs |

DrPlumbing's honeypot also returns success; that accepted limitation remains until a separate server acceptance change. The report label is **requests sent**, never leads. Definitions: [metrics matrix](../../docs/spikes/jda-213-website-analytics/metrics-matrix.md).

## Later: one pasted tag

**Available after publication and the required security review only:**

~~~html
<script async src="https://unpkg.com/mappack-web-analytics@0.1.0/dist/tag.js"
        data-id="G-XXXXXXXXXX" data-hosts="example.com,www.example.com"></script>
~~~

The tag counts page views and supported taps. A site still owns its booking events; the tag cannot know that a hosted form's server accepted a request.

## Data boundary

Only `link_text`, `page_path`, `service`, `city`, `urgency`, and the three allowed failure reasons pass to custom events. Unknown keys and nonstrings are dropped. The filter drops emails and seven or more digits with ordinary phone separators **before** truncation (100 characters, 40 for link labels). Hrefs, names, phone fields and messages are never passed. Callers must use categorical labels: this filter is a last boundary, not a detector for arbitrary personal prose.

Hosts must match exactly; localhost and Pages previews stay disabled. The package injects Google's gtag script at runtime and turns Google signals off. The owner decides consent and configures enhanced measurement. GA4's own automatic collection has its own behavior; the publishing security review must cover that behavior and site URLs too.

Chose one delegated listener and one parameter boundary over per-link hooks: all current links work without editing their components, and the site handles only events its form knows. See the [admin install guide](https://mappack-docs.web.app/#analytics/analytics).
